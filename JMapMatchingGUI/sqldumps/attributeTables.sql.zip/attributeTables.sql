/*
 Navicat Premium Data Transfer

 Source Server         : bikeability
 Source Server Type    : PostgreSQL
 Source Server Version : 90100
 Source Host           : localhost
 Source Database       : bikeability
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90100
 File Encoding         : utf-8

 Date: 10/12/2011 05:56:58 AM
*/

-- ----------------------------
--  Table structure for "bicycletype"
-- ----------------------------
DROP TABLE IF EXISTS "bicycletype";
CREATE TABLE "bicycletype" (
	"id" int2 NOT NULL,
	"descr" char(16)
)
WITH (OIDS=FALSE);
ALTER TABLE "bicycletype" OWNER TO "biker";

-- ----------------------------
--  Records of "bicycletype"
-- ----------------------------
BEGIN;
INSERT INTO "bicycletype" VALUES ('0', null);
INSERT INTO "bicycletype" VALUES ('1', 'no              ');
INSERT INTO "bicycletype" VALUES ('2', 'track           ');
INSERT INTO "bicycletype" VALUES ('3', 'dismount        ');
INSERT INTO "bicycletype" VALUES ('4', 'yes             ');
INSERT INTO "bicycletype" VALUES ('5', 'designated      ');
INSERT INTO "bicycletype" VALUES ('6', 'permissive      ');
COMMIT;

-- ----------------------------
--  Primary key structure for table "bicycletype"
-- ----------------------------
ALTER TABLE "bicycletype" ADD CONSTRAINT "cyclewaytype_copy_pkey" PRIMARY KEY ("id") NOT DEFERRABLE INITIALLY IMMEDIATE;

/*
 Navicat Premium Data Transfer

 Source Server         : bikeability
 Source Server Type    : PostgreSQL
 Source Server Version : 90100
 Source Host           : localhost
 Source Database       : bikeability
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90100
 File Encoding         : utf-8

 Date: 10/12/2011 05:57:11 AM
*/

-- ----------------------------
--  Table structure for "cyclewaytype"
-- ----------------------------
DROP TABLE IF EXISTS "cyclewaytype";
CREATE TABLE "cyclewaytype" (
	"id" int2 NOT NULL,
	"descr" char(16)
)
WITH (OIDS=FALSE);
ALTER TABLE "cyclewaytype" OWNER TO "biker";

-- ----------------------------
--  Records of "cyclewaytype"
-- ----------------------------
BEGIN;
INSERT INTO "cyclewaytype" VALUES ('0', null);
INSERT INTO "cyclewaytype" VALUES ('1', 'track           ');
INSERT INTO "cyclewaytype" VALUES ('2', 'undefined       ');
INSERT INTO "cyclewaytype" VALUES ('3', 'opposite_track  ');
INSERT INTO "cyclewaytype" VALUES ('4', 'path            ');
INSERT INTO "cyclewaytype" VALUES ('5', 'segregated      ');
INSERT INTO "cyclewaytype" VALUES ('6', 'no              ');
INSERT INTO "cyclewaytype" VALUES ('7', 'opposite        ');
INSERT INTO "cyclewaytype" VALUES ('8', 'lane            ');
INSERT INTO "cyclewaytype" VALUES ('9', 'none            ');
INSERT INTO "cyclewaytype" VALUES ('10', 'opposite_lane   ');
INSERT INTO "cyclewaytype" VALUES ('11', 'shared          ');
INSERT INTO "cyclewaytype" VALUES ('12', 'yes             ');
COMMIT;

-- ----------------------------
--  Primary key structure for table "cyclewaytype"
-- ----------------------------
ALTER TABLE "cyclewaytype" ADD CONSTRAINT "cyclewaytype_pkey" PRIMARY KEY ("id") NOT DEFERRABLE INITIALLY IMMEDIATE;

/*
 Navicat Premium Data Transfer

 Source Server         : bikeability
 Source Server Type    : PostgreSQL
 Source Server Version : 90100
 Source Host           : localhost
 Source Database       : bikeability
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90100
 File Encoding         : utf-8

 Date: 10/12/2011 05:57:17 AM
*/

-- ----------------------------
--  Table structure for "cyktype"
-- ----------------------------
DROP TABLE IF EXISTS "cyktype";
CREATE TABLE "cyktype" (
	"id" int2 NOT NULL,
	"descr" char(64)
)
WITH (OIDS=FALSE);
ALTER TABLE "cyktype" OWNER TO "biker";

-- ----------------------------
--  Records of "cyktype"
-- ----------------------------
BEGIN;
INSERT INTO "cyktype" VALUES ('0', 'Street with no facility                                         ');
INSERT INTO "cyktype" VALUES ('1', 'Bike path along street                                          ');
INSERT INTO "cyktype" VALUES ('2', 'Bike lane along street                                          ');
INSERT INTO "cyktype" VALUES ('3', 'Path, exclusively for bikes                                     ');
INSERT INTO "cyktype" VALUES ('4', 'Path, shared bikes and pedestrians                              ');
COMMIT;

-- ----------------------------
--  Primary key structure for table "cyktype"
-- ----------------------------
ALTER TABLE "cyktype" ADD CONSTRAINT "EnvType_copy_pkey" PRIMARY KEY ("id") NOT DEFERRABLE INITIALLY IMMEDIATE;

/*
 Navicat Premium Data Transfer

 Source Server         : bikeability
 Source Server Type    : PostgreSQL
 Source Server Version : 90100
 Source Host           : localhost
 Source Database       : bikeability
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90100
 File Encoding         : utf-8

 Date: 10/12/2011 05:57:23 AM
*/

-- ----------------------------
--  Table structure for "envtype"
-- ----------------------------
DROP TABLE IF EXISTS "envtype";
CREATE TABLE "envtype" (
	"id" int2 NOT NULL,
	"descr" char(64)
)
WITH (OIDS=FALSE);
ALTER TABLE "envtype" OWNER TO "biker";

-- ----------------------------
--  Records of "envtype"
-- ----------------------------
BEGIN;
INSERT INTO "envtype" VALUES ('0', 'NULL                                                            ');
INSERT INTO "envtype" VALUES ('1', 'Primary Road                                                    ');
INSERT INTO "envtype" VALUES ('2', 'Secondary Road                                                  ');
INSERT INTO "envtype" VALUES ('3', 'Others                                                          ');
INSERT INTO "envtype" VALUES ('4', 'Residential street (detached or semi-detached housing)          ');
INSERT INTO "envtype" VALUES ('5', 'Residential street (multistory housing)                         ');
INSERT INTO "envtype" VALUES ('6', 'Shopping street (multistory housing with shops)                 ');
INSERT INTO "envtype" VALUES ('7', 'Path, exclusively for bikes                                     ');
INSERT INTO "envtype" VALUES ('8', 'Path, shared bikes and pedestrians                              ');
COMMIT;

-- ----------------------------
--  Primary key structure for table "envtype"
-- ----------------------------
ALTER TABLE "envtype" ADD CONSTRAINT "foottype_copy_pkey" PRIMARY KEY ("id") NOT DEFERRABLE INITIALLY IMMEDIATE;

/*
 Navicat Premium Data Transfer

 Source Server         : bikeability
 Source Server Type    : PostgreSQL
 Source Server Version : 90100
 Source Host           : localhost
 Source Database       : bikeability
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90100
 File Encoding         : utf-8

 Date: 10/12/2011 05:57:28 AM
*/

-- ----------------------------
--  Table structure for "foottype"
-- ----------------------------
DROP TABLE IF EXISTS "foottype";
CREATE TABLE "foottype" (
	"id" int2 NOT NULL,
	"descr" char(16)
)
WITH (OIDS=FALSE);
ALTER TABLE "foottype" OWNER TO "biker";

-- ----------------------------
--  Records of "foottype"
-- ----------------------------
BEGIN;
INSERT INTO "foottype" VALUES ('0', null);
INSERT INTO "foottype" VALUES ('1', 'unknown         ');
INSERT INTO "foottype" VALUES ('2', 'no              ');
INSERT INTO "foottype" VALUES ('3', 'destination     ');
INSERT INTO "foottype" VALUES ('4', 'yes             ');
INSERT INTO "foottype" VALUES ('5', 'permissive      ');
INSERT INTO "foottype" VALUES ('6', 'designated      ');
COMMIT;

-- ----------------------------
--  Primary key structure for table "foottype"
-- ----------------------------
ALTER TABLE "foottype" ADD CONSTRAINT "cyclewaytype_copy_pkey2" PRIMARY KEY ("id") NOT DEFERRABLE INITIALLY IMMEDIATE;

/*
 Navicat Premium Data Transfer

 Source Server         : bikeability
 Source Server Type    : PostgreSQL
 Source Server Version : 90100
 Source Host           : localhost
 Source Database       : bikeability
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90100
 File Encoding         : utf-8

 Date: 10/12/2011 05:57:32 AM
*/

-- ----------------------------
--  Table structure for "highwaytype"
-- ----------------------------
DROP TABLE IF EXISTS "highwaytype";
CREATE TABLE "highwaytype" (
	"id" int2 NOT NULL,
	"descr" char(16)
)
WITH (OIDS=FALSE);
ALTER TABLE "highwaytype" OWNER TO "biker";

-- ----------------------------
--  Records of "highwaytype"
-- ----------------------------
BEGIN;
INSERT INTO "highwaytype" VALUES ('0', null);
INSERT INTO "highwaytype" VALUES ('1', 'primary         ');
INSERT INTO "highwaytype" VALUES ('2', 'secondary       ');
INSERT INTO "highwaytype" VALUES ('3', 'unclassified    ');
INSERT INTO "highwaytype" VALUES ('4', 'footway         ');
INSERT INTO "highwaytype" VALUES ('5', 'track           ');
INSERT INTO "highwaytype" VALUES ('6', 'service         ');
INSERT INTO "highwaytype" VALUES ('7', 'cycleway        ');
INSERT INTO "highwaytype" VALUES ('8', 'living_street   ');
INSERT INTO "highwaytype" VALUES ('9', 'path            ');
INSERT INTO "highwaytype" VALUES ('10', 'tertiary        ');
INSERT INTO "highwaytype" VALUES ('11', 'residential     ');
INSERT INTO "highwaytype" VALUES ('12', 'steps           ');
INSERT INTO "highwaytype" VALUES ('13', 'pedestrian      ');
INSERT INTO "highwaytype" VALUES ('14', 'primary_link    ');
COMMIT;

-- ----------------------------
--  Primary key structure for table "highwaytype"
-- ----------------------------
ALTER TABLE "highwaytype" ADD CONSTRAINT "cyclewaytype_copy_pkey1" PRIMARY KEY ("id") NOT DEFERRABLE INITIALLY IMMEDIATE;

/*
 Navicat Premium Data Transfer

 Source Server         : bikeability
 Source Server Type    : PostgreSQL
 Source Server Version : 90100
 Source Host           : localhost
 Source Database       : bikeability
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90100
 File Encoding         : utf-8

 Date: 10/12/2011 05:57:37 AM
*/

-- ----------------------------
--  Table structure for "segregatedtype"
-- ----------------------------
DROP TABLE IF EXISTS "segregatedtype";
CREATE TABLE "segregatedtype" (
	"id" int2 NOT NULL,
	"descr" char(16)
)
WITH (OIDS=FALSE);
ALTER TABLE "segregatedtype" OWNER TO "biker";

-- ----------------------------
--  Records of "segregatedtype"
-- ----------------------------
BEGIN;
INSERT INTO "segregatedtype" VALUES ('0', null);
INSERT INTO "segregatedtype" VALUES ('1', 'no              ');
INSERT INTO "segregatedtype" VALUES ('2', 'yes             ');
COMMIT;

-- ----------------------------
--  Primary key structure for table "segregatedtype"
-- ----------------------------
ALTER TABLE "segregatedtype" ADD CONSTRAINT "highwaytype_copy_pkey" PRIMARY KEY ("id") NOT DEFERRABLE INITIALLY IMMEDIATE;

